import fblib
import numpy as np
from itertools import count
import os.path

"""
    Some module documentation....

    .. doctest:: 

       >>> print "hw!"
       hw!
    
"""

class Uniton(type):

    """
       The Uniton is a special case of the Vulgion
       and ensures inheritance of certain properties of 
       the primeordial instance for all consecutive instances. 

    """
    #__instance = None
   
    def __init__(self, *args, **kwargs):
        self.__instance = None
        super(Uniton, self).__init__(*args, **kwargs)
       
    def __call__(cls, *args, **kwargs):
        if cls.__instance is None:
            print "uniton does its init work"
            cls.__instance = super(Uniton, cls).__call__(*args, **kwargs)
            cls.__instance._setupfb()
            cls.__instance.origo = (0,0)
            cls.__instance.size = (cls.width, cls.height)
            cls.__instance.pixelstyle = Pixelstyle()
        else:
            cls.__instance = super(Uniton, cls).__call__(*args, **kwargs)
        cls.instances.append(cls.__instance)
        return cls.__instance


class Bounds(object):

    def __init__(self, function):
        self.function = function

    def adjust(self, x, maxi):
        #if float then assume scaled
        #and scale it:
        if (type(x) == float):
            #if x<0 :x=0
            #if x>1 :x=1
            x = x * (maxi-1)
        return x % maxi

    def __call__(self, *args, **kwargs):
        origo = args[0].origo
        size = args[0].size
        pixelstyle = args[0].pixelstyle
        width = size[0]
        height = size[1]
        maxx=width
        maxy=height
        #should let the driver know about the winsize
        #args[0].winsize = (origo[0],origo[1],size[0],size[1], args[0].pixelstyle)
        args[0].informdriver()
        new_args = []
        firstarray = True

        for i, X in enumerate(args):
            if isinstance(X, tuple):
                x = self.adjust(X[0],maxx)
                y = self.adjust(X[1],maxy)
                x = x + origo[0]
                y = y + origo[1]
                new_args.append((int(x),int(y)))
            elif isinstance(X, np.ndarray):
                X = np.where(X>=0,X,0)
                X = np.where(X<=1,X,1)
                if firstarray:
                    X *= (maxx-1)
                    X += origo[0]
                    firstarray = False
                else:
                    X *= (maxy-1)
                    X += origo[1]
                X = X.astype(np.int32)    
                new_args.append(X)
            else:
                new_args.append(X)
            args = tuple(new_args)

        return self.function(*args, **kwargs) 

    def __get__(self, instance, owner):
        def wrapper(*args, **kwargs):
            return self(instance, *args, **kwargs)
        wrapper.__doc__ = self.function.__doc__
        wrapper.__name__ = self.function.__name__
        return wrapper

class Color(object):
    def __init__(self, *args):
        if args:
            self.r = args[0]
            self.g = args[1]
            self.b = args[2]
            self.a = args[3]
        else:
            self.r=0
            self.g=0
            self.b=0
            self.a=0

    def __repr__(self):
        return "Red={0}, Green={1}, Blue={2}, Alpha={3}".format(self.r,self.g,self.b,self.a)

    @property
    def red(self):
        return self.r

    @red.setter
    def red(self, red):
        self.r = red

    @property
    def green(self):
        return self.g

    @green.setter
    def green(self, green):
        self.g = green

    @property
    def blue(self):
        return self.b

    @blue.setter
    def blue(self, blue):
        self.b = blue

    @property
    def alpha(self):
        return self.a

    @alpha.setter
    def alpha(self, alpha):
        self.a = alpha

class Pixelstyle(object):

    def __init__(self, *args, **kwargs):
        self.color = Colors.white
        self.style = Styles.solid
        self.blur = 0
        self.blurradius = 1
        self.sigma = 1

class Geom(object):

    def __init__(self, selfy, *args):
        self.args = args
        self.parent = selfy

    def keep(self):
        self.parent.objects.append(self)

    def redraw(self):
        pass

class Rect(Geom):

    def redraw(self):
        self.parent.rect(*args)

class Line(Geom):

    def redraw(self):
        self.parent.line(*args)

class Point(object):

    def redraw(self):
        self.parent.point(*args)

class Coordinate(object):

    def __init__(self,x, y):
        self.x = x
        self.y = y

    def postprocess(self):
        pass    

def docme():
    return "Surface object of the fbpy module."

class Colors(object):
    """
        Some prefab colors, to make life easier.

        Food for Pixelstyle. e.g.:

    """

    black = Color(0,0,0,0)
    white = Color(255,255,255,0)
    grey = Color(100,100,100,0)
    darkgrey = Color(30,30,30,0)
    green = Color(0,255,0,0)
    darkgreen =  Color(0,100,0,0)
    magenta = Color(0,170,170,0)

class Styles(object):
    solid = 0
    dotted = 2
    dashed = 1

class Pixelstyles(object):
    faint = Pixelstyle()
    faint.blur = 2
    faint.blurradius = 2
    faint.style = Styles.solid
    faint.sigma = 1
    faint.color = Color(60,60,130,100)

    sharp = Pixelstyle()
    sharp.blur =0
    sharp.style = Styles.solid
    sharp.blurradius = 1
    sharp.sigma =1
    sharp.color = Colors.white

class Surface(object):
    """
        This is the main class, it generates a drawing surface.
        On first invokation, it will generate a surface which
        encompasses the entire screen automaticaly *and* it
        will open the framebuffer device.
        The classmethod close will close it. 
        Subsequent instances will need arguments defining size and
        position.

    """

    __metaclass__ = Uniton

    #__doc__ = docme()
    instances = []
    width = 0
    height = 0

    def __init__(self, *args):
        self.origo = (0,0)
        self.size = None
        self.sprite = None

        self.pixelstyle = Pixelstyle()

        if len(args)==2:
            if isinstance(args[0], tuple) and isinstance(args[1],tuple):
                self.origo = args[0]
                self.size = args[1]
                print self.origo
                print self.size
                self.informdriver()

        self.objects = []

    def informdriver(self):
        """
            pass relevant class info to
            fbutils driver,
            this is how one 'instance' of the
            driver can serve multiple Surface
            instances
        """

        fblib.fbsetwinparams(   self.origo[0], self.origo[1], self.size[0], self.size[1], 
                                self.pixelstyle.color.r,
                                self.pixelstyle.color.g,
                                self.pixelstyle.color.b,
                                self.pixelstyle.color.a,
                                self.pixelstyle.style,
                                self.pixelstyle.blur, self.pixelstyle.blurradius, 
                                self.pixelstyle.sigma)

    @classmethod
    def _setupfb(cls):
        fblib.fbsetup()
        
        cls.width = fblib.fbgetWidth()
        cls.height = fblib.fbgetHeight()
        print cls.width
        print cls.height


    @property
    def focus(self):
        return -1

    @focus.setter
    def focus(self, r):
        self.blurradius = r
        fblib.fbfocus(r)

    @property
    def winsize(self):
       return (self.origo,self.size)

    @winsize.setter
    def winsize(self, X):
        x0 = X[0]
        y0 = X[1]
        w = X[2]
        h = X[3]
        self.origo = (x0,y0)
        self.size = (w,h)
        self.informdriver()
        self.focus = self.blurradius

    def _set_color_(self, color):
        fblib.fbsetcolor(color.r,color.g,color.b,color.a)

    def _set_color2_(self, color):
         fblib.fbsetcolor2(color.r,color.g,color.b,color.a)

    def _set_style_(self, style_):
        fblib.fbsetstyle(style_)

    def set_dotstyle(self, dotstyle, blurrad_):
        """
            set_dotstyle(<dotstlyle>, <blur radius>)

            dotstyle 0 : fast plot
            dotstyle 1 : plot with soft alpha
            dotstyle 2 : plot with blur + soft alpha

            blur radius: well, 2 sigma ^2 it is

        """
        self.blur = dotstyle
        self.blurradius = blurrad_
        self.informdriver()

    def __repr__(self):
        return "framebuffer surface Object\nw:{0}\nh:{1}\n".format(self.width, self.height)

    def clear(self):
        """
            will make blackscreen
        """
        self.informdriver() 
        fblib.fbclearscreen()

    def update(self):
        """
            update()
            draws the buffered geometries. So, you need this before you actualy see 
            anything

        """
        self.informdriver()
        fblib.fbupdate()

    def keepbackground(self):
        return fblib.fbkeepcurrent()

    def store(self):
        self.sprite = self.get_raw()
        return 0

    def restore(self):
        self.set_raw(self.sprite)
        return 0

    def get_raw(self):
        """
            get_raw()

            returns an raw bitmap array of the current window, use
            set_raw to put the bitmap back.

            .. code-block::

               sprite = main.get_raw()
               main.set_raw(sprite)

        """

        length = self.size[0]*self.size[1]*4
        sprite = np.zeros(length, dtype=np.int32)
        fblib.fbgetraw(sprite)
        return sprite

    def set_raw(self, sprite):
        """
            set_raw(sprite)

            puts the bitmap array into the buffer, see get_raw.
        """
        self.informdriver()
        fblib.fbsetraw(sprite)

    def swap(self, page):
        print "fappen"
        fblib.fbswap(page)

    def fill(self,color):
        self._set_color_(color) 
        fblib.fbclearscreen()

    @Bounds
    def poly(self, xdata, ydata):
        """
            poly(<xdata numpy array>, <ydata numpy array>)

            x, y will be the points, have to be the same length and type

            style = 0, 1, 2
            0: solid line
            1: dashed line
            2: dotted line

            .. doctest::

               >>> import fbpy.fb as fb

               >>> import numpy as np

               >>> x = np.arange(0, 1,0.01)

               >>> y = 0.5*np.sin(x*2*2*np.pi) + 0.5

               >>> main  = fb.Surface()

               >>> subwin = fb.Surface((0,0),(200,200))
               (0, 0)
               (200, 200)
               >>> subwin.clear()
               0
               >>> subwin.pixelstyle = fb.Pixelstyles.faint

               >>> subwin.poly(x, y)
               0
               >>> subwin.grabsilent("./source/images/poly.png")
               0

            .. image:: ./images/poly.png

    
        """

        if  isinstance(xdata, np.ndarray) and isinstance(ydata, np.ndarray):
            if xdata.dtype == np.int32 and ydata.dtype == np.int32:
                pass
            else:
                raise NameError("something wrong with the array")
        else:
            xdata = np.array(xdata, dtype=np.int32)
            ydata = np.array(ydata, dtype=np.int32)

        if len(xdata) == len(ydata):
            fblib.fbpoly(xdata, ydata)
        pass

    @Bounds
    def line(self,X1, X2):
        """
            line(<tuple crd from>,<tuple crd to>)

            or

        """
        
        self._set_color_(color)
        self._set_style_(style)
        fblib.fbline(X1[0], X1[1], X2[0], X2[1])
        return Line(self, X1, X2, color)

    @Bounds
    def arc(self, X1, R1, R2, startseg, endseg, segs):
        rx=self.size[0] * R1/2
        ry=self.size[1] * R2/2
        fblib.fbarc(X1[0], X1[1], rx, ry, startseg, endseg, segs)  
        return 0

    @Bounds
    def circle(self, X1, R1):
        self._set_color_(color)
        self._set_style_(style)
        fblib.fbarc(X1[0],X1[1],R1*self.size[0],R1*self.size[1],0,segs,segs) 
        return 0

    @Bounds
    def rect(self, X1, X2):
        """
            rect(<tuple>, <tuple>, <fb color>, <style>)
            
            Will draw a rectangle @ first tuple, width and height
            as in second tuple


        """

        fblib.fbline(X1[0],X1[1],X2[0],X1[1])
        fblib.fbline(X1[0],X1[1],X1[0],X2[1])
        fblib.fbline(X1[0],X2[1],X2[0],X2[1])
        fblib.fbline(X2[0],X1[1],X2[0],X2[1])
        #return Rect(self, X1, X2, color)
        return 0

    @Bounds
    def printxy(self, X1, string, size_):
        """
            printxy (<tuple>, <string>, <size>)
            
            Will print text in string at position defined by tuple (x, y).

            Size can be 1 or 2, where 2 prints triple sized LCD-like format
            
            returns 0

            .. doctest::

               >>> import fbpy.fb as fb
               
               >>> main = fb.Surface()
               uniton does its work
               1366
               768
               >>> sub = fb.Surface((0,0),(800,100))
               (0, 0)
               (800, 100)
               >>> sub.clear()
               0
               >>> sub.printxy((10,10),"Hello world!", 2)
               0 
               >>> sub.printxy((10,38),"or a bit smaller...", 1)
               0
               >>> sub.grabsilent("./source/images/printxy.png")
               0               

            .. image:: ./images/printxy.png


        """

        fblib.fbprint(X1[0],X1[1], string, size_)
        return 0

    @Bounds
    def graticule(self, X1, WH):
        """
            graticule(<tuple>,<tuple>, <fb.color>, <fb.color>)

            draws scope-like graticule @ first tuple of size second tuple
            (width/height). color = subs, color2 main

            returns 0

            .. doctest::

               >>> import fbpy.fb as fb

               >>> main  = fb.Surface()
               uniton does its work
               1366
               768
               >>> sub2 = fb.Surface((0,0),(200,200))
               (0, 0)
               (200, 200)
               >>> sub2.clear() == 0
               True
               >>> sub2.pixelstyle.color = fb.Color(200,200,200,00) 
                 
               >>> sub2.fillrect((0,0),(200,200)) == 0
               True
               >>> sub2.pixelstyle.color = fb.Colors.white

               >>> sub2.graticule((0.0,0.0),(1.0,1.0)) == 0
               True
               >>> sub2.grabsilent("./source/images/graticule.png") == 0
               True

            .. image:: ./images/graticule.png

        """
        
        fblib.fbgraticule(X1[0],X1[1],WH[0]-X1[0],WH[1]-X1[1])
        return 0

    @Bounds
    def fillrect(self, X1, WH):
        fblib.fbfillrect(X1[0],X1[1],WH[0],WH[1])
        return 0

    def snow(self):
        self.informdriver()
        fblib.fbsnow()
        return 0

    @Bounds
    def point(self, X1):
        fblib.fbplot(X1[0],X1[1])
        #return Point(self, X1, color)

    def add(self, x):
        if isinstance(x, Line): print "Adding line"
        self.objects.append(x)      

    def grab(self,filename):
        """
            grab(<filename>)

            grabs current frame into file <filename>.png
        """
        self.informdriver()
        return fblib.fbgrab(filename)

    def grabsilent(self, filename):
        """
            grabsilent(<filename>)

            grabs current buffer into file <filename>.png

            so, if you dont use update, you'll never actually 
            *see* the drawing. Handy for doctest stuff 
            of other apps where you *only* wanna make 
            pics..
        """
        self.informdriver()
        return fblib.fbgrabsilent(filename)

    def grabsequence(self, filename):
        """
            grabsequence(<filename>)

            grabs current frame into file with filename <filename#>

            where # is an automatich counter. the output will be e.g.:
            screenshot0001.png, screenshot0002.png, ...

            you can use e.g. 
            
            .. code-block:: console

               nerd@wonka: ~/tmp$ avconv -i <filename>%04d.png -c:v huffyuv <yourmoviename>.avi  

            to convert the sequence to a movie.
            You can also use ofcourse somehtin like
            
            .. code-block:: console

               nerd@wonka: ~/tmp$ avconv -f fbdev -r 10 -i /dev/fb0 -c:v huffyuv /dev/shm/movi.avi 2> /dev/null 
            
        """

        numbered_filename = ("{}{:04d}.png".format(filename, i) for i in count(1))

        try_this = next(numbered_filename)

        while os.path.isfile(try_this):
            try_this = next(numbered_filename)

        self.grab(try_this)

        return 0

    def redraw(self):
        for i, elem in enumerate(self.objects):
            elem.redraw()

    def something(self):
        """
            .. doctest::

               >>> print "Hello from a doctest.."
               Hello from a doctest..

        """

    @classmethod
    def close(self):
        self._Uniton__instance = None

        fblib.fbclose()
        return 0

if __name__ == '__main__':
    pass

