#include <stdio.h>

void main()
{
start:
	printf("Hello world!\n");
	goto start;
}

