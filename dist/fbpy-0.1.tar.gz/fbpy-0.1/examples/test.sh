clear
python ./testhigh.py > /dev/null

