import fbpy.fb as fb
import pdb

if __name__ == '__main__':
    main = fb.Surface()
    sub = fb.Surface((100,100),(100,100))
    pdb.set_trace()



