import fbpy.audioscope as audioscope
import fbpy.fb as fb

if __name__ == '__main__':
    main  = fb.Surface()
    scope = audioscope.Scope((10,10),(300,200))
    
    
